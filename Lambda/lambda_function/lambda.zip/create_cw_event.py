import boto3
from config import config
import os

os.environ["AWS_DEFAULT_REGION"] = config.default_region
client = boto3.client('events')
USERNAME_KEY = "userName"

def create_cloudwatch_event(event, context): 
    username = event[USERNAME_KEY]
    print(username)


def build_cloudwatch_event(eventName):
    # Every SUNDAY
    scheduleExpression = "cron(0 12 ? * SUN *)"
    client.put_rule(
        Name=eventName,
        ScheduleExpression=scheduleExpression,
        State='DISABLED'
    )